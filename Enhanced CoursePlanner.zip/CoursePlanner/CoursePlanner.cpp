// CoursePlanner.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

//CS 300 Project Two: Advising Assistance Program
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <unordered_map>
#include <limits>

using namespace std;

// Convert a string to uppercase
string toUpperCase(string str) {
    transform(str.begin(), str.end(), str.begin(), ::toupper);
    return str;
}

struct Course {
    string courseNumber;
    string courseTitle;
    vector<string> prerequisites;
};

vector<Course> courseList;
unordered_map<string, Course> courseTable;

// Check whether course data has been loaded
bool isDataLoaded() {
    return !courseList.empty() && !courseTable.empty();
}

// Function to load the course data
void loadDataStructure() {
    string filename;
    cout << "Enter the name of the input file (press Enter to use default): ";
    getline(cin, filename); // prompt for filename
    if (filename.empty()) {
        filename = "CS 300 ABCU_Advising_Program_Input.csv"; // use default if empty
    }

    ifstream file(filename); // open file with name filename
    if (!file) {
        cerr << "Error: Could not open file " << filename << endl;
        return;
    }

    // Clear existing data to prevent duplicates if file is loaded again
    courseList.clear();
    courseTable.clear();

    string line;
    int lineNumber = 0;

    while (getline(file, line)) {
        lineNumber++;

        vector<string> fields;
        stringstream ss(line);
        string field;

        // Split line by commas and store each field
        while (getline(ss, field, ',')) {
            fields.push_back(field);
        }

        // Validate that course number and title exist
        if (fields.size() < 2 || fields[0].empty() || fields[1].empty()) {
            cout << "Skipping invalid line " << lineNumber
                 << ": missing course number or title.\n";
            continue;
        }

        Course course;
        course.courseNumber = fields[0];
        course.courseTitle = fields[1];

        // Add prerequisites if they exist
        for (size_t i = 2; i < fields.size(); ++i) {
            if (!fields[i].empty()) {
                course.prerequisites.push_back(fields[i]);
            }
        }

        string courseKey = toUpperCase(course.courseNumber);

        // Prevent duplicate course entries
        if (courseTable.find(courseKey) != courseTable.end()) {
            cout << "Skipping duplicate course on line " << lineNumber
                 << ": " << course.courseNumber << endl;
            continue;
        }

        // Store course in both vector and hash table
        courseList.push_back(course);
        courseTable[courseKey] = course;
    }

    file.close();
    cout << "Course data loaded successfully.\n";
}

// Function to print all courses in alphanumeric order
void printCourseList() {

    // Prevent printing before data is loaded
    if (!isDataLoaded()) {
        cout << "Please load the course data first.\n";
        return;
    }

    // sort courseList by courseNumber
    sort(courseList.begin(), courseList.end(), [](const Course& a, const Course& b) {
        return a.courseNumber < b.courseNumber;
        });

    cout << "Here is a sample schedule:\n";
    // for each course, print courseNumber and courseTitle
    for (const Course& course : courseList) {
        cout << course.courseNumber << ", " << course.courseTitle << endl;
    }
}

// Function to print a single course by course number
void printCourse() {

    // Prevent searching before data is loaded
    if (!isDataLoaded()) {
        cout << "Please load the course data first.\n";
        return;
    }

    string searchNumber;

    // Get course number from user
    cout << "What course do you want to know about? ";
    cin >> searchNumber;
    cin.ignore();

    // Convert input to uppercase for consistent searching
    searchNumber = toUpperCase(searchNumber);

    // Search for course in the hash table
    auto it = courseTable.find(searchNumber);

    // If course is found, print course details
    if (it != courseTable.end()) {
        Course course = it->second;

        cout << course.courseNumber << ", " << course.courseTitle << endl;
        cout << "Prerequisites: ";

        // Print None if there are no prerequisites
        if (course.prerequisites.empty()) {
            cout << "None" << endl;
        }
        else {
            // Print prerequisites separated by commas
            for (size_t i = 0; i < course.prerequisites.size(); ++i) {
                cout << course.prerequisites[i];

                if (i < course.prerequisites.size() - 1) {
                    cout << ", ";
                }
            }
            cout << endl;
        }
    }
    else {
        // Display message if course is not found
        cout << "Course not found.\n";
    }
}

int main() {
    int choice = 0;

    while (choice != 9) {
        cout << "\n1. Load Data Structure.\n";
        cout << "2. Print Course List.\n";
        cout << "3. Print Course.\n";
        cout << "9. Exit.\n";
        cout << "What would you like to do? ";

        cin >> choice;

        // Validate menu input
        if (cin.fail()) {
            cin.clear(); // clear error state
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // remove bad input
            cout << "Invalid input. Please enter a number.\n";
            continue;
        }

        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // clear leftover newline

        switch (choice) {
        case 1:
            loadDataStructure();
            break;
        case 2:
            printCourseList();
            break;
        case 3:
            printCourse();
            break;
        case 9:
            cout << "Thank you for using the course planner!\n";
            break;
        default:
            cout << choice << " is not a valid option.\n";
        }
    }

    return 0;
}